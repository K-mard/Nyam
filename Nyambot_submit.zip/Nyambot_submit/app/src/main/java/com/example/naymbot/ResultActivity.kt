package com.example.naymbot

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.example.naymbot.ui.theme.NaymbotTheme

class ResultActivity : ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // MainActivity에서 전달한 결과 문자열 받기
        val mealResult = intent.getStringExtra("meal_result") ?: "결과가 없습니다."
        val age = intent.getStringExtra("age") ?: "-"
        val gender = intent.getStringExtra("gender") ?: "-"
        val goal = intent.getStringExtra("goal") ?: "-"

        setContent {
            NaymbotTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    ResultScreen(
                        resultText = mealResult,
                        age = age,
                        gender = gender,
                        goal = goal,
                        onBack = { finish() }   // 뒤로가기 버튼 눌렀을 때 액티비티 종료
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultScreen(
    resultText: String,
    age: String,
    gender: String,
    goal: String,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("AI 식단 추천 결과") },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "뒤로가기"
                        )
                    }
                }
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 상단 요약
            Text(
                text = "오늘의 추천 요약",
                style = MaterialTheme.typography.titleLarge
            )

            Text(
                text = "나이: $age / 성별: $gender / 목표: $goal",
                style = MaterialTheme.typography.bodyMedium
            )

            // 결과 카드
            Text(
                text = "AI가 제안한 식단",
                style = MaterialTheme.typography.titleMedium
            )

            Card(
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(
                    text = resultText,
                    modifier = Modifier.padding(16.dp)
                )
            }

            Spacer(modifier = Modifier.weight(1f))

            Button(
                onClick = onBack,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("입력 화면으로 돌아가기")
            }
        }
    }
}