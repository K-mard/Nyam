package com.example.naymbot

object MealAiService {

    fun callAiMealPlan(
        age: String,
        gender: String,
        goal: String,
        like: String,
        dislike: String
    ): String {
        // 나중에 여기 부분을 GPT API 호출 교체.
        return generateMealPlan(age, gender, goal, like, dislike)
    }

    fun generateMealPlan(
        age: String,
        gender: String,
        goal: String,
        like: String,
        dislike: String
    ): String {

        val breakfastOptions = when (goal) {
            "다이어트" -> listOf("오트밀 + 바나나", "그릭요거트 + 견과류", "샐러드 + 삶은 계란")
            "유지" -> listOf("현미밥 + 계란말이", "두부 샐러드", "김치볶음밥")
            else -> listOf("닭가슴살 샌드위치", "연어죽", "연어 덮밥")
        }

        val lunchOptions = when (goal) {
            "다이어트" -> listOf("닭가슴살 샐러드", "연어 샐러드", "야채 비빔밥")
            "유지" -> listOf("제육볶음 + 현미밥", "된장찌개 + 밥", "불고기덮밥")
            else -> listOf("삼겹살 + 상추쌈", "카레라이스", "파스타 + 닭가슴살")
        }

        val dinnerOptions = when (goal) {
            "다이어트" -> listOf("채소 스프", "두부 스테이크", "구운 채소 + 닭가슴살")
            "유지" -> listOf("순두부찌개 + 밥", "볶음밥", "야채 비빔밥")
            else -> listOf("닭갈비 + 밥", "라면 + 계란 + 김치", "불고기 전골")
        }

        return """
        [오늘의 AI 추천 식단]

        🌅 아침 : ${breakfastOptions.random()}
        🍛 점심 : ${lunchOptions.random()}
        🌙 저녁 : ${dinnerOptions.random()}

        좋아하는 음식 : $like
        피하고 싶은 음식 : $dislike
        목표 : $goal
    """.trimIndent()
    }

    // 1️⃣ 프롬프트 설계 (발표 핵심)
    private fun buildPrompt(
        age: String,
        gender: String,
        goal: String,
        like: String,
        dislike: String
    ): String {
        return """
            너는 전문 영양사 AI다.
            
            사용자 정보:
            - 나이: $age
            - 성별: $gender
            - 목표: $goal
            - 좋아하는 음식: $like
            - 피하고 싶은 음식: $dislike
            
            위 정보를 기반으로
            아침, 점심, 저녁 식단을 추천해줘.
            간단한 설명도 포함해줘.
        """.trimIndent()
    }

    // 2️⃣ 지금은 가짜 AI (나중에 GPT API로 교체)
    suspend fun requestMealPlan(
        age: String,
        gender: String,
        goal: String,
        like: String,
        dislike: String
    ): String {
        val prompt = buildPrompt(age, gender, goal, like, dislike)

        // TODO: 나중에 여기서 GPT API 호출
        val request = ChatRequest(
            messages = listOf(
                Message(role = "user", content = prompt)
            )
        )
        val response = OpenAiClient.api.chatCompletion(request)
        return response.choices.first().message.content

    }

    // 3️⃣ 임시 응답
    private fun mockResponse(prompt: String): String {
        return """
            [AI 식단 추천 결과]

            🌅 아침: 오트밀 + 바나나
            🍛 점심: 닭가슴살 샐러드
            🌙 저녁: 현미밥 + 연어구이

            ✔ 목표에 맞는 균형 잡힌 식단입니다.
        """.trimIndent()
    }
}