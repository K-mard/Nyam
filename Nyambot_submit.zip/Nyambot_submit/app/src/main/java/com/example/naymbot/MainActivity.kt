package com.example.naymbot

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.naymbot.ui.theme.NaymbotTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.TopAppBar
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
//import com.example.naymbot.MealAiService.generateMealPlan


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NaymbotTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    SmartMealScreen()
                }
            }
        }
    }
}
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartMealScreen() {

    var isLoading by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val scope = rememberCoroutineScope()

    val context = LocalContext.current
    var age by remember { mutableStateOf("") }
    var gender by remember { mutableStateOf("남") }
    var goal by remember { mutableStateOf("다이어트") }
    var like by remember { mutableStateOf("") }
    var dislike by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    val goals = listOf("다이어트", "유지", "증량")

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("SmartMeal - AI 식단 추천") }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            item {
                Text(
                    text = "오늘의 식단 설정",
                    style = MaterialTheme.typography.titleLarge
                )
            }

            item {
                OutlinedTextField(
                    value = age,
                    onValueChange = { age = it },
                    label = { Text("나이") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Row {
                    RadioButton(selected = gender == "남", onClick = { gender = "남" })
                    Text("남", modifier = Modifier.padding(end = 12.dp))
                    RadioButton(selected = gender == "여", onClick = { gender = "여" })
                    Text("여")
                }
            }

            item {
                Text("목표 선택", style = MaterialTheme.typography.labelLarge)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    goals.forEach {
                        AssistChip(onClick = { goal = it }, label = { Text(it) })
                    }
                }
            }

            item {
                OutlinedTextField(
                    value = like,
                    onValueChange = { like = it },
                    label = { Text("좋아하는 음식 (선택)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                OutlinedTextField(
                    value = dislike,
                    onValueChange = { dislike = it },
                    label = { Text("피하고 싶은 음식 (선택)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }

            item {
                Button(
                    onClick = {
                        scope.launch {
                            isLoading = true
                            errorMessage = null

                            try {
                                val mealResult = MealAiService.requestMealPlan(
                                    age = age,
                                    gender = gender,
                                    goal = goal,
                                    like = like,
                                    dislike = dislike
                                )

                                val intent = Intent(context, ResultActivity::class.java).apply {
                                    putExtra("meal_result", mealResult)
                                    putExtra("age", age)
                                    putExtra("gender", gender)
                                    putExtra("goal", goal)
                                }
                                context.startActivity(intent)

                            } catch (e: Exception) {
                                errorMessage = "AI 서버 오류가 발생했습니다.\n다시 시도해주세요."
                            } finally {
                                isLoading = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    enabled = !isLoading
                ) {
                    if (isLoading) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(20.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("AI가 식단을 분석 중입니다...")
                    } else {
                        Text("AI에게 식단 추천 받기")
                    }
                }
            }

            if (errorMessage != null) {
                item {
                    Text(
                        text = errorMessage!!,
                        color = MaterialTheme.colorScheme.error
                    )
                }
            }


            if (result.isNotBlank()) {
                item {
                    Text(
                        text = "추천 결과",
                        style = MaterialTheme.typography.titleMedium
                    )
                }

                item {
                    Card(modifier = Modifier.fillMaxWidth()) {
                        Text(
                            text = result,
                            modifier = Modifier
                                .padding(16.dp)
                        )
                    }
                }
            }





        }
    }
}